import { Component, OnInit } from '@angular/core';
import { PostManagementService } from '../postManagementService';
import { Router } from '@angular/router';
import { UserAuthService } from '../../userAuth/userAuth.service';
import { response } from 'express';

@Component({
    selector: 'app-home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.css']
})

export class HomeComponent implements OnInit {

    posts: Array<any> = [];

    constructor(private postManagementService: PostManagementService, private userAuthService: UserAuthService, private router: Router) { 
        // postManagementService.getHomePosts(userAuthService.getAuthToken()).subscribe(
        //     (response) => {
        //         this.posts = response.posts;
        //         console.log(this.posts);
        //     },
        //     (error) => {
        //         console.error('Authentication error:', error);
        //         this.router.navigate(['/auth/login']);
        //     }
        // );
    }

    ngOnInit() {
    }

    likePost(postId: string) {
        this.postManagementService.likePost(this.userAuthService.getAuthToken(), postId).subscribe(
            (response) => {
                this.posts.forEach((post) => {
                    if(post.id == postId) {
                        post.isLikedByUser = true;
                        post.likeCount += 1;
                    }
                })
            },
            (error) => {
                console.error('Authentication error:', error);
                this.router.navigate(['/auth/login']);
            }
        );
    }


    unLikePost(postId: string) {
        this.postManagementService.unLikePost(this.userAuthService.getAuthToken(), postId).subscribe(
            (response) => {
                this.posts.forEach((post) => {
                    if(post.id == postId) {
                        post.isLikedByUser = false;
                        post.likeCount -= 1;
                    }
                })
            },
            (error) => {
                console.error('Authentication error:', error);
                this.router.navigate(['/auth/login']);
            }
        );
    }

}