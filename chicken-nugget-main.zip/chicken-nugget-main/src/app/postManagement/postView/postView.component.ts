import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-postView',
    templateUrl: './postView.component.html',
    styleUrls: ['./postView.component.css']
})

export class PostViewComponent implements OnInit {

    showDeleteCommentDropDown = false;
    showPostDeleteDropDown = false;

    ngOnInit() {
    }

}